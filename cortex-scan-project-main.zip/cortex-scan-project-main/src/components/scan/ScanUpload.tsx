
import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Upload, Image, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/hooks/useAuth';

interface ScanUploadProps {
  patientId: string;
  onScanUploaded: () => void;
}

export const ScanUpload = ({ patientId, onScanUploaded }: ScanUploadProps) => {
  const [isUploading, setIsUploading] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const { user } = useAuth();
  const { toast } = useToast();

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setSelectedFile(file);
      const reader = new FileReader();
      reader.onload = (e) => setPreview(e.target?.result as string);
      reader.readAsDataURL(file);
    }
  }, []);

  const handleUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!selectedFile || !user) return;

    setIsUploading(true);
    
    try {
      const formData = new FormData(e.currentTarget);
      const scanNotes = formData.get('scanNotes') as string;
      const technicianName = formData.get('technicianName') as string;
      const referringDoctor = formData.get('referringDoctor') as string;

      // Upload file to Supabase Storage
      const fileExt = selectedFile.name.split('.').pop();
      const fileName = `${user.id}/${Date.now()}.${fileExt}`;
      
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('mri-scans')
        .upload(fileName, selectedFile);

      if (uploadError) throw uploadError;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from('mri-scans')
        .getPublicUrl(fileName);

      // Save scan record to database
      const { error: dbError } = await supabase
        .from('scans')
        .insert({
          patient_id: patientId,
          image_url: publicUrl,
          original_filename: selectedFile.name,
          file_size: selectedFile.size,
          scan_notes: scanNotes,
          technician_name: technicianName,
          referring_doctor: referringDoctor,
          status: 'pending'
        });

      if (dbError) throw dbError;

      toast({
        title: "Success",
        description: "MRI scan uploaded successfully!"
      });

      // Reset form
      setSelectedFile(null);
      setPreview(null);
      onScanUploaded();
      
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to upload scan",
        variant: "destructive"
      });
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Upload className="h-5 w-5" />
          Upload MRI Scan
        </CardTitle>
        <CardDescription>
          Upload a new brain MRI scan for AI analysis
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleUpload} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="scan-file">MRI Image File</Label>
            <Input
              id="scan-file"
              type="file"
              accept="image/*,.dcm"
              onChange={handleFileSelect}
              required
            />
          </div>

          {preview && (
            <div className="mt-4">
              <Label>Preview</Label>
              <div className="mt-2 border rounded-lg p-4 bg-gray-50">
                <img 
                  src={preview} 
                  alt="MRI Preview" 
                  className="max-h-64 mx-auto rounded"
                />
              </div>
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="technician">Technician Name</Label>
              <Input
                id="technician"
                name="technicianName"
                placeholder="Enter technician name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="doctor">Referring Doctor</Label>
              <Input
                id="doctor"
                name="referringDoctor"
                placeholder="Enter referring doctor"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes">Scan Notes</Label>
            <Textarea
              id="notes"
              name="scanNotes"
              placeholder="Enter any additional notes about the scan..."
              rows={3}
            />
          </div>

          <Button 
            type="submit" 
            className="w-full" 
            disabled={!selectedFile || isUploading}
          >
            {isUploading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="mr-2 h-4 w-4" />
                Upload Scan
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};
